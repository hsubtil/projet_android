READ ME : Manuel d'utilisation Application Tchit Tchat : 
Vid�o : https://youtu.be/YpGPwKKDG5M

- Cliquer sur l'icon de l'application pour ouvrir la page de Login
- Vous arrivez sur la page de login :
	* Si vous �tes d�j� inscrit : taper username et password puis Sign in 
	* Si vous n'�tes pas inscrit : cliquer sur Sign up
- Si vous n'�tes pas inscrit : 
	* Vous �tes redirig� sur une page d'inscription 
	* Renseigner tous les champs (login, password, password confirmation, Email) puis cliquer sur Register !
	* Si les champs sont correctes vous �tes redirig� vers la page de Login
	* Sinon un message d'erreur s'affiche et vous demande de renseigner les champs correctement
- Si vous �tes inscrit : 
	* Vous �tes redirig� sur la Main Page
	* Les 100 derniers messages sont affich�s (avec les attachements si il y en a)
- Sur la Main Page vous pouvez : 
	* Envoyer des messages : la page s'actualise automatiquement et votre message apparait sans avoir besoin de refresh
	* Actualiser la page : En faisant un pull la page s'actualise
	* Acc�der � votre page de profile ou de contact
- La page de profile : 
	* Acc�s en cliquant sur le bouton profile de la Main Page
	* Affiche Login, Email et photo de profile
	* Acc�s � la page d'�dition de profile en cliquant sur le bouton "Edit Profile"
- La page Edit Profile : 
	* Possibilit� de changer le password et l'email
	* Lorsqu'un des 2 champs est renseign� cliquer sur Submit
	* Vous �tes redirig� sur la page de login pour vous reconnecter avec le nouveau mot de passe
- La page Contact : 
	* Possibilit� de faire une cherche par login
	* Taper le login que vous chercher puis cliquer sur le bouton Search 
	* Si le login existe : s'affiche le login et l'email du contact
	* Si le login n'existe pas : s'affiche un message d'erreur :"Le login n'existe pas"
